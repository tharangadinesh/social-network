package com.musala.socialnetwork.dto.mapper;

import com.musala.socialnetwork.dto.response.FollowershipResponseDto;
import com.musala.socialnetwork.entity.Follower;
import com.musala.socialnetwork.mapper.FollowershipMapper;
import com.musala.socialnetwork.utility.DummyUserDataUtil;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.assertEquals;

class FollowershipMapperTest {
    @InjectMocks
    private FollowershipMapper followershipMapper;

    private AutoCloseable closeable;

    @BeforeEach
    public void openMocks() {
        closeable = MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    public void releaseMocks() throws Exception {
        closeable.close();
    }

    @Test
    void test_FollowershipToFollowershipResponse() {

        // Arrange
        Follower followership = new Follower(1L, DummyUserDataUtil.createUser_1(), DummyUserDataUtil.createUser_2());
        FollowershipResponseDto expectedFollowershipResponse = FollowershipResponseDto.builder()
                .id(1L)
                .userId(1L)
                .followerId(2L)
                .build();

        // Act
        FollowershipResponseDto followershipResponseDto = followershipMapper.entityToResponseDto(followership);

        // Assert
        assertEquals(expectedFollowershipResponse.getId(), followershipResponseDto.getId());
        assertEquals(expectedFollowershipResponse.getFollowerId(), followershipResponseDto.getFollowerId());
        assertEquals(expectedFollowershipResponse.getUserId(), followershipResponseDto.getUserId());

    }
}