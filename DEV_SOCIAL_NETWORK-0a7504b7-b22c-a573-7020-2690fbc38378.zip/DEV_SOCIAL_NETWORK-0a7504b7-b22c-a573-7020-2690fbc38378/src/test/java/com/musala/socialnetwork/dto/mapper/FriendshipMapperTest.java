package com.musala.socialnetwork.dto.mapper;

import com.musala.socialnetwork.dto.response.FriendshipResponseDto;
import com.musala.socialnetwork.entity.Friend;
import com.musala.socialnetwork.mapper.FriendshipMapper;
import com.musala.socialnetwork.utility.DummyUserDataUtil;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.assertEquals;

class FriendshipMapperTest {
    @InjectMocks
    private FriendshipMapper friendshipMapper;

    private AutoCloseable closeable;

    @BeforeEach
    public void openMocks() {
        closeable = MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    public void releaseMocks() throws Exception {
        closeable.close();
    }

    @Test
    void test_FriendshipToFriendshipResponse() {

        // Arrange
        Friend friendship = new Friend(1L, DummyUserDataUtil.createUser_1(), DummyUserDataUtil.createUser_2());
        FriendshipResponseDto expectedFriendshipResponse = FriendshipResponseDto.builder()
                .id(1L)
                .userId(1L)
                .friendId(2L)
                .build();

        // Act
        FriendshipResponseDto friendshipResponseDto = friendshipMapper.entityToResponseDto(friendship);

        // Assert
        assertEquals(expectedFriendshipResponse.getId(), friendshipResponseDto.getId());
        assertEquals(expectedFriendshipResponse.getFriendId(), friendshipResponseDto.getFriendId());
        assertEquals(expectedFriendshipResponse.getUserId(), friendshipResponseDto.getUserId());

    }
}