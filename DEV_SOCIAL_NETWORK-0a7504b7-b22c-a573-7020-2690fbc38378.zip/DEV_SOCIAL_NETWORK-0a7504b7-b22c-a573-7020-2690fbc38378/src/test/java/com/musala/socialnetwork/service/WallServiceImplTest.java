package com.musala.socialnetwork.service;

import com.musala.socialnetwork.dto.response.PostResponseDto;
import com.musala.socialnetwork.entity.Post;
import com.musala.socialnetwork.entity.User;
import com.musala.socialnetwork.mapper.PostMapper;
import com.musala.socialnetwork.repository.PostRepository;
import com.musala.socialnetwork.service.handler.UserHandler;
import com.musala.socialnetwork.service.impl.WallServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

class WallServiceImplTest {

    @Mock
    private PostRepository postRepository;
    @Mock
    private PostMapper postMapper;
    @Mock
    private UserHandler userHandler;

    @InjectMocks
    private WallServiceImpl wallService;

    private AutoCloseable closeable;

    @BeforeEach
    public void openMocks() {
        closeable = MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    public void releaseMocks() throws Exception {
        closeable.close();
    }

    @Test
    void getPostsByUser_withValidInput() {

        // Arrange
        Long userId = 1L;

        User user = new User();
        user.setId(userId);

        User friend = new User();
        friend.setId(2L);

        User follower = new User();
        follower.setId(3L);

        Set<Post> userPosts = new HashSet<>();
        userPosts.add(createPost(userId));

        Set<Post> friendPosts = new HashSet<>();
        friendPosts.add(createPost(friend.getId()));

        Set<Post> followerPosts = new HashSet<>();
        followerPosts.add(createPost(follower.getId()));

        Set<User> friends = new HashSet<>();
        friends.add(friend);

        Set<User> followers = new HashSet<>();
        followers.add(follower);

        List<PostResponseDto> posts = new ArrayList<>();
        posts.addAll(postMapper.entityListToResponseList(userPosts.stream().toList()));
        posts.addAll(postMapper.entityListToResponseList(friendPosts.stream().toList()));
        posts.addAll(postMapper.entityListToResponseList(followerPosts.stream().toList()));

        when(userHandler.findById(userId)).thenReturn(user);
        when(userHandler.findById(friend.getId())).thenReturn(friend);
        when(userHandler.findById(follower.getId())).thenReturn(follower);

        when(postRepository.findAllByUser(userId)).thenReturn(userPosts);
        when(postRepository.findAllByUser(friend.getId())).thenReturn(friendPosts);
        when(postRepository.findAllPublicByUser(follower.getId())).thenReturn(followerPosts);
        when(wallService.getPostsByUser(userId)).thenReturn(posts);
        // Act
        List<PostResponseDto> actualPosts = wallService.getPostsByUser(userId);

        assertEquals(posts.size(), actualPosts.size());
    }

    private Post createPost(Long id) {
        Post post = new Post();
        post.setId(id);
        post.setText("Test post");
        post.setCreatedOn(LocalDateTime.now());
        return post;
    }
}

