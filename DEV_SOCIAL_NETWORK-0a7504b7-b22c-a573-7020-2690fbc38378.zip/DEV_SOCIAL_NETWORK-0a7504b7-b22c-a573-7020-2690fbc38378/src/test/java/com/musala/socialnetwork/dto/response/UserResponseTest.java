package com.musala.socialnetwork.dto.response;

import com.musala.socialnetwork.utility.DummyUserDataUtil;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UserResponseTest {

    @Test
    void test_NoArgsConstructor(){

        UserResponseDto userResponse = new UserResponseDto();

        assertNull(userResponse.getId());
    }

    @Test
    void test_AllArgsConstructor(){

        UserResponseDto resourceSkillRequestDTO = DummyUserDataUtil.createUserResponseDto_1();

        assertEquals(1L, resourceSkillRequestDTO.getId());
    }

    @Test
    void test_ToString() {

        //Act
        UserResponseDto userResponseDto = DummyUserDataUtil.createUserResponseDto_1();
        String expectedToString = "UserResponseDto(id=1, fullName=User 1)";

        // Assert
        assertEquals(expectedToString, userResponseDto.toString());
    }

    @Test
    void test_EqualsAndHashCode() {

        UserResponseDto userResponse_1 = DummyUserDataUtil.createUserResponseDto_1();
        UserResponseDto userResponse_2 = DummyUserDataUtil.createUserResponseDto_1();
        UserResponseDto userResponse_3 = DummyUserDataUtil.createUserResponseDto_2();

        assertEquals(userResponse_1, userResponse_2);
        assertNotEquals(userResponse_1, userResponse_3);
        assertNotEquals(null, userResponse_1);

        assertEquals(userResponse_1.hashCode(), userResponse_2.hashCode());
        assertNotEquals(userResponse_1.hashCode(), userResponse_3.hashCode());
    }
}