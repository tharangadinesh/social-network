package com.musala.socialnetwork.dto.response.common;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ApiResponseTest {

    @Test
    void testNoArgsConstructor() {
        ApiResponse<String> apiResponse = new ApiResponse<>();
        assertNull(apiResponse.getStatus());
        assertNull(apiResponse.getMessage());
        assertFalse(apiResponse.isSuccess());
        assertNull(apiResponse.getData());
    }

    @Test
    void testAllArgsConstructorWithData() {
        HttpStatus status = HttpStatus.OK;
        String message = "Success message";
        boolean success = true;
        String data = "Some data";

        ApiResponse<String> apiResponse = new ApiResponse<>(status, message, success, data);

        assertEquals(status, apiResponse.getStatus());
        assertEquals(message, apiResponse.getMessage());
        assertTrue(apiResponse.isSuccess());
        assertEquals(data, apiResponse.getData());
        assertNotNull(apiResponse);
        assertEquals(success, apiResponse.isSuccess());
    }

    @Test
    void testSetterAndGetterMethods() {
        ApiResponse<String> apiResponse = new ApiResponse<>();
        HttpStatus status = HttpStatus.BAD_REQUEST;
        String message = "Another message";
        boolean success = false;
        String data = "New data";
        List<String> datalist = new ArrayList<>();
        datalist.add("Data 1");

        apiResponse.setStatus(status);
        apiResponse.setMessage(message);
        apiResponse.setSuccess(success);
        apiResponse.setData(data);

        assertEquals(status, apiResponse.getStatus());
        assertEquals(message, apiResponse.getMessage());
        assertFalse(apiResponse.isSuccess());
        assertEquals(data, apiResponse.getData());
    }

    @Test
    void testEqualsAndHashCode() {
        ApiResponse<String> response1 = new ApiResponse<>(HttpStatus.OK, "Message", true, "Data");
        ApiResponse<String> response2 = new ApiResponse<>(HttpStatus.OK, "Message", true, "Data");
        ApiResponse<String> response3 = new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR, "Different Message", false, "Different Data");

        assertEquals(response1, response2);
        assertNotEquals(response1, response3);
        assertNotEquals(response2, response3);

        assertEquals(response1.hashCode(), response2.hashCode());
        assertNotEquals(response1.hashCode(), response3.hashCode());
        assertNotEquals(response2.hashCode(), response3.hashCode());
    }

    @Test
    void testToString() {
        ApiResponse<String> apiResponse = new ApiResponse<>(HttpStatus.OK, "Message", true, "Data");
        String expectedToString = "ApiResponse(status=200 OK, message=Message, success=true, data=Data)";
        assertEquals(expectedToString, apiResponse.toString());
    }


}

