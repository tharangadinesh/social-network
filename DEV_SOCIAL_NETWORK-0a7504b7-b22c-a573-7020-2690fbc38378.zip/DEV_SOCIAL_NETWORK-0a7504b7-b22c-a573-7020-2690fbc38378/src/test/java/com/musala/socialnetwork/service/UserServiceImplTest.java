package com.musala.socialnetwork.service;

import com.musala.socialnetwork.dto.request.UserRequestDto;
import com.musala.socialnetwork.dto.response.UserResponseDto;
import com.musala.socialnetwork.entity.User;
import com.musala.socialnetwork.exception.DataConflictException;
import com.musala.socialnetwork.mapper.UserMapper;
import com.musala.socialnetwork.repository.UserRepository;
import com.musala.socialnetwork.service.impl.UserServiceImpl;
import com.musala.socialnetwork.utility.DummyUserDataUtil;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UserServiceImplTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private UserMapper userMapper;

    @InjectMocks
    private UserServiceImpl userService;

    private AutoCloseable closeable;

    @BeforeEach
    public void openMocks() {
        closeable = MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    public void releaseMocks() throws Exception {
        closeable.close();
    }

    @Test
    void createUser_withNewUser() {
        UserRequestDto requestDto = DummyUserDataUtil.createUserRequestDto_1();
        User user = DummyUserDataUtil.createUser_1();
        UserResponseDto responseDto = new UserResponseDto();

        when(userRepository.findByFullName(anyString())).thenReturn(Optional.empty());
        when(userRepository.save(user)).thenReturn(user);
        when(userMapper.entityToResponseDto(any())).thenReturn(responseDto);

        assertEquals(responseDto, userService.createUser(requestDto));

    }

    @Test
    void createUser_withExistingUser() {
        UserRequestDto requestDto = new UserRequestDto();
        requestDto.setFullName("Existing User");

        when(userRepository.findByFullName(anyString())).thenReturn(Optional.of(new User()));

        Exception exception = assertThrows(DataConflictException.class, () -> userService.createUser(requestDto));
        assertTrue(exception.getMessage().contains("already exist"));
    }
}

