package com.musala.socialnetwork.exception;


import com.musala.socialnetwork.dto.response.common.ErrorResponseDTO;
import jakarta.validation.ValidationException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import java.nio.file.AccessDeniedException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.mockito.Mockito.mock;

class GlobalExceptionHandlerTest {

    @InjectMocks
    private GlobalExceptionHandler globalExceptionHandler;

    private AutoCloseable closeable;

    @BeforeEach
    public void openMocks() {
        closeable = MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    public void releaseMocks() throws Exception {
        closeable.close();
    }

    @Test
    void handleAccessDeniedException() {
        // Arrange
        AccessDeniedException exception = new AccessDeniedException("Access Denied");
        WebRequest webRequest = mock(WebRequest.class);

        // Act
        ResponseEntity<Object> responseEntity = globalExceptionHandler.handleAccessDeniedException(exception, webRequest);

        // Assert
        assertEquals(HttpStatus.UNAUTHORIZED, responseEntity.getStatusCode());
    }

    @Test
    void handleNotFoundException() {
        // Arrange
        ObjectNotFoundException objectNotFoundException = new ObjectNotFoundException("Object not found");
        WebRequest webRequest = mock(WebRequest.class);

        // Act
        ResponseEntity<Object> responseEntity = globalExceptionHandler.handleNotFoundException(objectNotFoundException, webRequest);

        // Assert
        assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
    }

    @Test
    void handleCommonServerException() {
        // Arrange
        CommonServerException exception = new CommonServerException("Internal server error");
        WebRequest webRequest = mock(WebRequest.class);

        // Act
        ResponseEntity<Object> responseEntity = globalExceptionHandler.handleCommonServerException(exception, webRequest);

        // Assert
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
    }

    @Test
    void handleDataConflictException() {
        // Arrange
        DataConflictException exception = new DataConflictException("Data conflict");
        WebRequest webRequest = mock(WebRequest.class);

        // Act
        ResponseEntity<Object> responseEntity = globalExceptionHandler.handleDataConflictException(exception, webRequest);

        // Assert
        assertEquals(HttpStatus.CONFLICT, responseEntity.getStatusCode());
    }

    @Test
    void handleMethodArgumentNotValidException() {
        // Arrange
        MethodArgumentNotValidException ex = mock(MethodArgumentNotValidException.class);
        WebRequest webRequest = mock(WebRequest.class);

        // Act
        ResponseEntity<Object> response = globalExceptionHandler.handleMethodArgumentNotValidException(ex, webRequest);

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertInstanceOf(ErrorResponseDTO.class, response.getBody());
        ErrorResponseDTO<Object> errorResponse = (ErrorResponseDTO<Object>) response.getBody();
        assertEquals(HttpStatus.BAD_REQUEST, errorResponse.getStatus());
    }

    @Test
    void handleMethodArgumentTypeMismatchException() {
        // Arrange
        MethodArgumentTypeMismatchException ex = mock(MethodArgumentTypeMismatchException.class);
        WebRequest webRequest = mock(WebRequest.class);
        // Act
        ResponseEntity<Object> response = globalExceptionHandler.handleMethodArgumentTypeMismatchException(ex, webRequest);

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertInstanceOf(ErrorResponseDTO.class, response.getBody());
        ErrorResponseDTO<Object> errorResponse = (ErrorResponseDTO<Object>) response.getBody();
        assertEquals(HttpStatus.BAD_REQUEST, errorResponse.getStatus());
    }

    @Test
    void handleValidationException() {
        // Arrange
        ValidationException ex = mock(ValidationException.class);
        WebRequest webRequest = mock(WebRequest.class);

        // Act
        ResponseEntity<Object> response = globalExceptionHandler.handleValidationException(ex, webRequest);

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertInstanceOf(ErrorResponseDTO.class, response.getBody());
        ErrorResponseDTO<Object> errorResponse = (ErrorResponseDTO<Object>) response.getBody();
        assertEquals(HttpStatus.BAD_REQUEST, errorResponse.getStatus());
    }

}