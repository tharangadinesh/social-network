package com.musala.socialnetwork.utility;

import com.musala.socialnetwork.dto.request.UserRequestDto;
import com.musala.socialnetwork.dto.response.UserResponseDto;
import com.musala.socialnetwork.entity.Follower;
import com.musala.socialnetwork.entity.Friend;
import com.musala.socialnetwork.entity.User;

import java.util.List;

public class DummyUserDataUtil {

    private static String NAME_1 = "User 1";
    private static String NAME_2 = "User 2";

    public static UserResponseDto createUserResponseDto_1() {

        return UserResponseDto.builder()
                .id(1L)
                .fullName(NAME_1)
                .build();
    }

    public static UserResponseDto createUserResponseDto_2() {

        return UserResponseDto.builder()
                .id(2L)
                .fullName(NAME_2)
                .build();
    }

    public static UserRequestDto createUserRequestDto_1() {

        return UserRequestDto.builder()
                .fullName(NAME_1)
                .build();
    }

    public static User createUser_1() {

        return User.builder()
                .id(1L)
                .fullName(NAME_1)
                .friends(List.of(new Friend(1L,
                        new User(2L, "User 2", null, null),
                        new User(3L, "User 3", null, null))))

                .followers(List.of(
                        new Follower(1L,
                                new User(2L, "User 2", null, null),
                                new User(3L, "User 3", null, null))))
                .build();
    }

    public static User createUser_2() {

        return User.builder()
                .id(2L)
                .fullName(NAME_2)
                .friends(List.of(new Friend(2L,
                        new User(2L, "User 2", null, null),
                        new User(3L, "User 3", null, null))))
                .followers(List.of(
                        new Follower(2L,
                                new User(2L, "User 2", null, null),
                                new User(3L, "User 3", null, null))))
                .build();
    }

}
