package com.musala.socialnetwork.service;

import com.musala.socialnetwork.entity.Post;
import com.musala.socialnetwork.entity.PostLike;
import com.musala.socialnetwork.entity.User;
import com.musala.socialnetwork.repository.PostLikeRepository;
import com.musala.socialnetwork.service.handler.PostHandler;
import com.musala.socialnetwork.service.handler.UserHandler;
import com.musala.socialnetwork.service.impl.PostLikeServiceImpl;
import com.musala.socialnetwork.utility.DummyPostDataUtil;
import com.musala.socialnetwork.utility.DummyUserDataUtil;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.mockito.Mockito.*;

class PostLikeServiceImplTest {

    @Mock
    private PostHandler postHandler;
    @Mock
    private PostLikeRepository postLikeRepository;
    @Mock
    private UserHandler userHandler;

    @InjectMocks
    private PostLikeServiceImpl postLikeService;

    private AutoCloseable closeable;

    @BeforeEach
    public void openMocks() {
        closeable = MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    public void releaseMocks() throws Exception {
        closeable.close();
    }


    @Test
    void likePost_withValidInput() {
        Post post = new Post();
        User user = new User();
        PostLike postLike = PostLike.builder().post(post).user(user).build();

        when(postHandler.findById(any())).thenReturn(post);
        when(userHandler.findById(any())).thenReturn(user);
        when(postLikeRepository.save(any(PostLike.class))).thenReturn(postLike);

        postLikeService.likePost(1L, 2L);

        verify(postLikeRepository, times(1)).save(any(PostLike.class));
    }

    @Test
    void unlikePost_withValidPostLike() {

        Optional<PostLike> postLike = Optional.of(new PostLike(1L,
                DummyPostDataUtil.createPost_1(),
                DummyUserDataUtil.createUser_1())
        );

        when(postLikeRepository.findByPostAndUser(any(), any())).thenReturn(postLike);
       doNothing().when(postLikeRepository).delete(postLike.get());

        when(postHandler.findById(1L)).thenReturn(DummyPostDataUtil.createPost_1());

        postLikeService.unlikePost(1L, 2L);

        verify(postLikeRepository, times(1)).delete(any(PostLike.class));
    }

}

