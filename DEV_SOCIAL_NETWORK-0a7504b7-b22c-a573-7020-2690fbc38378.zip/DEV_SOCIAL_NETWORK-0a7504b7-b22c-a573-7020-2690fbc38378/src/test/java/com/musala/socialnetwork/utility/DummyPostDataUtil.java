package com.musala.socialnetwork.utility;

import com.musala.socialnetwork.constant.PostVisibility;
import com.musala.socialnetwork.dto.request.PostRequestDto;
import com.musala.socialnetwork.dto.response.PostResponseDto;
import com.musala.socialnetwork.entity.Post;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

public class DummyPostDataUtil {

    public static final String POST = "Post 1";
    public static final String POST_2 = "Post 2";

    public static final LocalDateTime LOCAL_DATE_TIME = LocalDateTime.of(2024, 3,1, 0,0,0);

    public static PostResponseDto createPostResponseDto_1() {

        return PostResponseDto.builder()
                .id(1L)
                .text("Sample Post")
                .visibility(PostVisibility.PUBLIC)
                .likeCount(1)
                .userId(1L)
                .postedOn(LocalDateTimeUtil.formatDateTime(LOCAL_DATE_TIME))
                .isLiked(false)
                .build();
    }

    public static PostResponseDto createPostResponseDto_2() {

        return PostResponseDto.builder()
                .id(2L)
                .text("Sample Post 2")
                .visibility(PostVisibility.PRIVATE)
                .likeCount(1)
                .userId(1L)
                .postedOn(LocalDateTimeUtil.formatDateTime(LOCAL_DATE_TIME))
                .isLiked(false)
                .build();
    }

    public static PostRequestDto createPostRequestDto_1() {

        return PostRequestDto.builder()
                .text("Sample Post")
                .visibility(PostVisibility.PRIVATE)
                .userId(1L)
                .build();
    }

    public static PostRequestDto createPostRequestDto_2() {

        return PostRequestDto.builder()
                .text("Sample Post")
                .visibility(PostVisibility.PUBLIC)
                .userId(1L)
                .build();
    }

    public static Post createPost_1() {

        return Post.builder()
                .id(1L)
                .text("Sample Post 1")
                .visibility(PostVisibility.PRIVATE)
                .likeCount(1)
                .createdOn(LocalDateTimeUtil.getCurrentDateTime())
                .user(DummyUserDataUtil.createUser_1())
                .build();
    }

    public static Post createPost_2() {

        return Post.builder()
                .id(2L)
                .text("Sample Post 2")
                .visibility(PostVisibility.PRIVATE)
                .likeCount(1)
                .createdOn(LocalDateTimeUtil.getCurrentDateTime())
                .user(DummyUserDataUtil.createUser_1())
                .build();
    }

    private static Date convertToDate(LocalDateTime localDateTime) {
        return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
    }

}
