package com.musala.socialnetwork.service;

import com.musala.socialnetwork.dto.request.PostRequestDto;
import com.musala.socialnetwork.dto.response.PostResponseDto;
import com.musala.socialnetwork.entity.Post;
import com.musala.socialnetwork.exception.UserNotFoundException;
import com.musala.socialnetwork.mapper.PostMapper;
import com.musala.socialnetwork.repository.PostRepository;
import com.musala.socialnetwork.repository.UserRepository;
import com.musala.socialnetwork.service.handler.UserHandler;
import com.musala.socialnetwork.service.impl.PostServiceImpl;
import com.musala.socialnetwork.utility.DummyPostDataUtil;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class PostServiceImplTest {

    @Mock
    private PostRepository postRepository;
    @Mock
    private UserRepository userRepository;
    @Mock
    private PostMapper postMapper;
    @Mock
    private UserHandler userHandler;

    @InjectMocks
    private PostServiceImpl postService;

    private AutoCloseable closeable;

    @BeforeEach
    public void openMocks() {
        closeable = MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    public void releaseMocks() throws Exception {
        closeable.close();
    }

    @Test
    void test_whenValidInput_thenCreatePost() {
        // Arrange
        PostRequestDto postRequestDto = DummyPostDataUtil.createPostRequestDto_1();

        PostResponseDto expectedPostResponse = DummyPostDataUtil.createPostResponseDto_1();
        Post expectedPost = DummyPostDataUtil.createPost_1();

        when(postMapper.requestDtoToEntity(postRequestDto)).thenReturn(expectedPost);
        when(postMapper.entityToResponseDto(expectedPost)).thenReturn(expectedPostResponse);
        when(postRepository.save(expectedPost)).thenReturn(expectedPost);

        // Act
        PostResponseDto postPostResponse = postService.createPost(postRequestDto);

        // Assert
        assertNotNull(postPostResponse);
        assertEquals(expectedPostResponse, postPostResponse);

        verify(postRepository, times(1)).save(expectedPost);
    }

    @Test
    void test_createPost_userNotFound() {
        PostRequestDto postRequest = new PostRequestDto();
        postRequest.setUserId(999L);
        when(userHandler.findById(999L)).thenThrow(new UserNotFoundException("User Not Found"));

        assertThrows(UserNotFoundException.class, () -> postService.createPost(postRequest));

        verify(userHandler, times(1)).findById(999L);
    }
}

