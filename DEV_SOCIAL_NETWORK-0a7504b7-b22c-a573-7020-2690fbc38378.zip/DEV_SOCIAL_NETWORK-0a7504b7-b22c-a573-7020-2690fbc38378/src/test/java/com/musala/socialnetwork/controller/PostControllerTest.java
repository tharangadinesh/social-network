package com.musala.socialnetwork.controller;

import com.musala.socialnetwork.dto.request.PostRequestDto;
import com.musala.socialnetwork.dto.response.PostResponseDto;
import com.musala.socialnetwork.dto.response.common.ApiResponse;
import com.musala.socialnetwork.service.PostLikeService;
import com.musala.socialnetwork.service.PostService;
import com.musala.socialnetwork.utility.DummyPostDataUtil;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Objects;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

class PostControllerTest {

    @Mock
    private PostService postService;
    @Mock
    private PostLikeService postLikeService;

    @InjectMocks
    private PostRestController postController;

    private AutoCloseable closeable;

    @BeforeEach
    public void openMocks() {
        closeable = MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    public void releaseMocks() throws Exception {
        closeable.close();
    }

    @Test
    void test_whenValidInput_thenCreatePost() {
        // Arrange
        PostRequestDto postRequestDtoDTO = DummyPostDataUtil.createPostRequestDto_1();

        PostResponseDto postResponse = DummyPostDataUtil.createPostResponseDto_1();

        when(postService.createPost(postRequestDtoDTO)).thenReturn(postResponse);

        // Act
        ResponseEntity<ApiResponse<PostResponseDto>> responseEntity = postController.createPost(postRequestDtoDTO);

        // Assert
        assertNotNull(responseEntity);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals("The post has been created successfully", Objects.requireNonNull(Objects.requireNonNull(responseEntity.getBody()).getMessage()));
        assertEquals(HttpStatus.CREATED, responseEntity.getBody().getStatus());
        assertEquals(postResponse, responseEntity.getBody().getData());

        verify(postService, times(1)).createPost(postRequestDtoDTO);
    }

    @Test
    void test_UnlikePost_Success() throws Exception {

        Long postId = 1L;
        Long userId = 1L;

        doNothing().when(postLikeService).unlikePost(postId, userId);

        // Act
        postController.unlikePost(postId, userId);

        verify(postLikeService, times(1)).unlikePost(postId, userId);
    }

    @Test
    void test_LikePost_Success() throws Exception {

        Long postId = 1L;
        Long userId = 1L;

        doNothing().when(postLikeService).likePost(postId, userId);

        // Act
        postController.likePost(postId, userId);

        verify(postLikeService, times(1)).likePost(postId, userId);
    }

}

