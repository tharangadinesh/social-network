package com.musala.socialnetwork.dto.response.common;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class ErrorResponseDtoTest {

    @Test
    void testNoArgsConstructor() {
        ErrorResponseDTO<String> errorResponse = new ErrorResponseDTO<>();
        assertNull(errorResponse.getStatus());
        assertNull(errorResponse.getMessage());
        assertNull(errorResponse.getData());
        assertNull(errorResponse.getDate());
    }

    @Test
    void testAllArgsConstructor() {
        LocalDateTime knownDate = LocalDateTime.of(2023, 9, 11, 17, 0);
        HttpStatus status = HttpStatus.BAD_REQUEST;
        String message = "Error message";
        String data = "Additional data";

        ErrorResponseDTO<String> errorResponse = new ErrorResponseDTO<>(status, message, knownDate, data);

        assertEquals(status, errorResponse.getStatus());
        assertEquals(message, errorResponse.getMessage());
        assertEquals(data, errorResponse.getData());
        assertEquals(knownDate, errorResponse.getDate());
    }

    @Test
    void testSetterAndGetterMethods() {
        LocalDateTime knownDate = LocalDateTime.of(2023, 9, 11, 17, 0);
        ErrorResponseDTO<String> errorResponse = new ErrorResponseDTO<>();
        HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
        String message = "Another error message";
        String data = "New data";

        errorResponse.setStatus(status);
        errorResponse.setMessage(message);
        errorResponse.setData(data);
        errorResponse.setDate(knownDate);

        assertEquals(status, errorResponse.getStatus());
        assertEquals(message, errorResponse.getMessage());
        assertEquals(data, errorResponse.getData());
        assertEquals(knownDate, errorResponse.getDate());
    }

    @Test
    void testEqualsAndHashCode() {
        LocalDateTime knownDate = LocalDateTime.of(2023, 9, 11, 17, 0);
        ErrorResponseDTO<String> errorResponse1 = new ErrorResponseDTO<>(HttpStatus.BAD_REQUEST, "Message", knownDate, "Data");
        ErrorResponseDTO<String> errorResponse2 = new ErrorResponseDTO<>(HttpStatus.BAD_REQUEST, "Message", knownDate, "Data");
        ErrorResponseDTO<String> errorResponse3 = new ErrorResponseDTO<>(HttpStatus.INTERNAL_SERVER_ERROR, "Different Message", knownDate, "Different Data");

        assertEquals(errorResponse1, errorResponse2);
        assertNotEquals(errorResponse1, errorResponse3);
        assertNotEquals(errorResponse2, errorResponse3);

        assertEquals(errorResponse1.hashCode(), errorResponse2.hashCode());
        assertNotEquals(errorResponse1.hashCode(), errorResponse3.hashCode());
        assertNotEquals(errorResponse2.hashCode(), errorResponse3.hashCode());
    }

    @Test
    void testToString() {
        // Create a known date value
        LocalDateTime knownDate = LocalDateTime.of(2023, 9, 11, 17, 0);
        // Create the expected ErrorResponseDTO with the known date
        ErrorResponseDTO<String> expectedErrorResponse = new ErrorResponseDTO<>(HttpStatus.BAD_REQUEST, "Message", knownDate, "Data");

        // Create the actual ErrorResponseDTO with the known date
        ErrorResponseDTO<String> actualErrorResponse = new ErrorResponseDTO<>();
        actualErrorResponse.setStatus(HttpStatus.BAD_REQUEST);
        actualErrorResponse.setMessage("Message");
        actualErrorResponse.setData("Data");
        actualErrorResponse.setDate(knownDate);

        // Compare the two instances
        assertEquals(expectedErrorResponse.toString(), actualErrorResponse.toString());
    }

}

