package com.musala.socialnetwork.controller;

import com.musala.socialnetwork.dto.response.PostResponseDto;
import com.musala.socialnetwork.dto.response.common.ApiResponse;
import com.musala.socialnetwork.service.WallService;
import com.musala.socialnetwork.utility.DummyPostDataUtil;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

class WallControllerTest {

    @Mock
    private WallService wallService;

    @InjectMocks
    private WallRestController wallRestController;

    private AutoCloseable closeable;

    @BeforeEach
    public void openMocks() {
        closeable = MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    public void releaseMocks() throws Exception {
        closeable.close();
    }

    @Test
    void test_GetWallPosts() {
        // Prepare mock data
        List<PostResponseDto> wallResponses = List.of(
                DummyPostDataUtil.createPostResponseDto_1(),
                DummyPostDataUtil.createPostResponseDto_2()
        );

        when(wallService.getPostsByUser(1L)).thenReturn(wallResponses);

        // Perform the test
        ResponseEntity<ApiResponse<List<PostResponseDto>>> responseEntity = wallRestController.getPostsByUser(1L);

        // Verify that the controller returns the expected status code and message
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals("A list of all the posts made by the user, their friends, and people they follow, sorted by timestamp descending", Objects.requireNonNull(responseEntity.getBody()).getMessage());
        assertTrue(responseEntity.getBody().isSuccess());
        assertEquals(wallResponses, responseEntity.getBody().getData());

        // Verify that the wallService.getWall() method was called
        verify(wallService, times(1)).getPostsByUser(1L);
    }

}

