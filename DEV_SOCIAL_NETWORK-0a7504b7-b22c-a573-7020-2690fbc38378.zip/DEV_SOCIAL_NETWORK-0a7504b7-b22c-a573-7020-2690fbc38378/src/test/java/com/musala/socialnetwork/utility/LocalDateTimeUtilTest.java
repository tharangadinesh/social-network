package com.musala.socialnetwork.utility;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

import static org.junit.jupiter.api.Assertions.*;

class LocalDateTimeUtilTest {

    @Test
    void test_GetCurrentDateTime_returnsCurrentTime() {
        // Act
        LocalDateTime dateTime = LocalDateTimeUtil.getCurrentDateTime();

        // Assert
        assertNotNull(dateTime);
    }

    @Test
    void test_FormatDateTime_formatsWithDefaultPattern() {
        // Arrange
        LocalDateTime dateTime = LocalDateTime.now();
        String expectedPattern = "yyyy-MM-dd HH:mm:ss";

        // Act
        String formattedDateTime_1 = LocalDateTimeUtil.formatDateTime(dateTime, expectedPattern);
        String formattedDateTime_2 = LocalDateTimeUtil.formatDateTime(dateTime);

        // Assert
        assertTrue(formattedDateTime_1.matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}"));
        assertTrue(formattedDateTime_2.matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}"));
    }

    @Test
    void test_FormatDateTime_withCustomPattern() {
        // Arrange
        LocalDateTime dateTime = LocalDateTime.now();
        String customPattern = "yyyy-MM-dd HH:mm:ss";
        String expectedFormatted = dateTime.format(DateTimeFormatter.ofPattern(customPattern));

        // Act
        String formattedDateTime = LocalDateTimeUtil.formatDateTime(dateTime, customPattern);

        // Assert
        assertEquals(expectedFormatted, formattedDateTime);
    }

    @Test
    void test_FormatDateTime_withPatternAndZone() {
        // Arrange
        LocalDateTime dateTime = LocalDateTime.now();
        String pattern = "yyyy-MM-dd HH:mm:ss";
        String timeZone = "UTC";
        String expectedFormatted = dateTime.atZone(ZoneId.of(timeZone)).format(DateTimeFormatter.ofPattern(pattern));

        // Act
        String formattedDateTime = LocalDateTimeUtil.formatDateTime(dateTime, pattern, timeZone);

        // Assert
        assertEquals(expectedFormatted, formattedDateTime);
    }

    @Test
    void test_GetCurrentDateTime_withTimeZone_returnsCorrectTime() {
        // Arrange
        String expectedZone = "Asia/Kolkata";

        // Act
        LocalDateTime dateTime = LocalDateTimeUtil.getCurrentDateTime(expectedZone);
        ZonedDateTime zonedDateTime = dateTime.atZone(ZoneId.of(expectedZone));

        // Assert
        assertEquals(ZoneId.of(expectedZone), zonedDateTime.getZone());
    }
}
