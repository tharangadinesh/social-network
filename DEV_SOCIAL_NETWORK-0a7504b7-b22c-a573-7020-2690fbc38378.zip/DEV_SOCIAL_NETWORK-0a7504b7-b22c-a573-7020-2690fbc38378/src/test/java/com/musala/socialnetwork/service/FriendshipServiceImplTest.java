package com.musala.socialnetwork.service;

import com.musala.socialnetwork.dto.response.FriendshipResponseDto;
import com.musala.socialnetwork.entity.Friend;
import com.musala.socialnetwork.entity.User;
import com.musala.socialnetwork.mapper.FriendshipMapper;
import com.musala.socialnetwork.repository.FriendRepository;
import com.musala.socialnetwork.service.handler.UserHandler;
import com.musala.socialnetwork.service.impl.FriendshipServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class FriendshipServiceImplTest {

    @Mock
    private FriendRepository friendRepository;
    @Mock
    private FriendshipMapper friendshipMapper;
    @Mock
    private UserHandler userHandler;

    @InjectMocks
    private FriendshipServiceImpl friendshipService;

    private AutoCloseable closeable;

    @BeforeEach
    public void openMocks() {
        closeable = MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    public void releaseMocks() throws Exception {
        closeable.close();
    }

    @Test
    void addFriend_withValidInput() {
        User user = new User();
        User friend = new User();
        Friend friendship = Friend.builder().user(user).friend(friend).build();
        FriendshipResponseDto responseDto = new FriendshipResponseDto();

        when(userHandler.findById(any())).thenReturn(user, friend);
        when(friendRepository.existsByUserAndFriend(any(), any())).thenReturn(Optional.empty());
        when(friendRepository.save(any(Friend.class))).thenReturn(friendship);
        when(friendshipMapper.entityToResponseDto(any())).thenReturn(responseDto);

        assertEquals(responseDto, friendshipService.addFriend(1L, 2L));

        verify(friendRepository, times(1)).save(friendship);
    }

    @Test
    void addFriend_whenAlreadyFriends() {
        when(userHandler.findById(any())).thenReturn(new User());
        when(friendRepository.existsByUserAndFriend(any(), any())).thenReturn(Optional.of(new Friend()));

        assertThrows(IllegalStateException.class, () -> friendshipService.addFriend(1L, 2L));
    }
}

