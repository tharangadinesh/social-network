package com.musala.socialnetwork.controller;

import com.musala.socialnetwork.dto.request.UserRequestDto;
import com.musala.socialnetwork.dto.response.UserResponseDto;
import com.musala.socialnetwork.dto.response.common.ApiResponse;
import com.musala.socialnetwork.service.UserService;
import com.musala.socialnetwork.utility.DummyUserDataUtil;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Objects;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

class UserControllerTest {

    @Mock
    private UserService userService;

    @InjectMocks
    private UserRestController userRestController;

    private AutoCloseable closeable;

    @BeforeEach
    public void openMocks() {
        closeable = MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    public void releaseMocks() throws Exception {
        closeable.close();
    }

    @Test
    void test_whenValidInput_thenCreateUser() {
        // Arrange
        UserRequestDto userRequestDtoDTO = DummyUserDataUtil.createUserRequestDto_1();

        UserResponseDto userResponse = DummyUserDataUtil.createUserResponseDto_1();

        when(userService.createUser(userRequestDtoDTO)).thenReturn(userResponse);

        // Act
        ResponseEntity<ApiResponse<UserResponseDto>> responseEntity = userRestController.createUser(userRequestDtoDTO);

        // Assert
        assertNotNull(responseEntity);

        assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());
        assertEquals("A new user has been created successfully.", Objects.requireNonNull(Objects.requireNonNull(responseEntity.getBody()).getMessage()));
        assertEquals(HttpStatus.CREATED, responseEntity.getBody().getStatus());
        assertEquals(userResponse, responseEntity.getBody().getData());

        verify(userService, times(1)).createUser(userRequestDtoDTO);
    }

}

