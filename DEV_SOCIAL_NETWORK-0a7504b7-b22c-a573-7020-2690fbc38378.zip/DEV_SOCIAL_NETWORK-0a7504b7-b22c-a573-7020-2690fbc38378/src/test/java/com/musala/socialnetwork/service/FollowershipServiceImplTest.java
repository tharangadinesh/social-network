package com.musala.socialnetwork.service;

import com.musala.socialnetwork.dto.response.FollowershipResponseDto;
import com.musala.socialnetwork.entity.Follower;
import com.musala.socialnetwork.entity.User;
import com.musala.socialnetwork.mapper.FollowershipMapper;
import com.musala.socialnetwork.repository.FollowerRepository;
import com.musala.socialnetwork.service.handler.UserHandler;
import com.musala.socialnetwork.service.impl.FollowershipServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class FollowershipServiceImplTest {

    @Mock
    private UserHandler userHandler;
    @Mock
    private FollowerRepository followerRepository;
    @Mock
    private FollowershipMapper followershipMapper;
    @InjectMocks
    private FollowershipServiceImpl followershipService;

    private AutoCloseable closeable;

    @BeforeEach
    public void openMocks() {
        closeable = MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    public void releaseMocks() throws Exception {
        closeable.close();
    }

    @Test
    void addFollower_withValidInput() {
        User user = new User();
        User follower = new User();
        Follower followership = Follower.builder().user(user).follower(follower).build();
        FollowershipResponseDto responseDto = new FollowershipResponseDto();

        when(userHandler.findById(any())).thenReturn(user, follower);
        when(followerRepository.existsByUserAndFollower(any(), any())).thenReturn(Optional.empty());
        when(followerRepository.save(any(Follower.class))).thenReturn(followership);
        when(followershipMapper.entityToResponseDto(any())).thenReturn(responseDto);

        assertEquals(responseDto, followershipService.addFollower(1L, 2L));

        verify(followerRepository, times(1)).save(followership);
    }

    @Test
    void addFollower_whenAlreadyFollowers() {
        when(userHandler.findById(any())).thenReturn(new User());
        when(followerRepository.existsByUserAndFollower(any(), any())).thenReturn(Optional.of(new Follower()));

        assertThrows(IllegalStateException.class, () -> followershipService.addFollower(1L, 2L));
    }
}

