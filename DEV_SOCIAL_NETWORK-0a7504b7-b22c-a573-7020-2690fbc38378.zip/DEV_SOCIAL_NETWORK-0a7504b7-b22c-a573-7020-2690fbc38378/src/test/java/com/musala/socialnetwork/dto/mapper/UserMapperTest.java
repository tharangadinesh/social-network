package com.musala.socialnetwork.dto.mapper;

import com.musala.socialnetwork.dto.request.UserRequestDto;
import com.musala.socialnetwork.dto.response.UserResponseDto;
import com.musala.socialnetwork.entity.User;
import com.musala.socialnetwork.mapper.UserMapper;
import com.musala.socialnetwork.utility.DummyUserDataUtil;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.assertEquals;

class UserMapperTest {
    @InjectMocks
    private UserMapper usersMapper;

    private AutoCloseable closeable;

    @BeforeEach
    public void openMocks() {
        closeable = MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    public void releaseMocks() throws Exception {
        closeable.close();
    }

    @Test
    void test_UserToUserResponse() {

        // Arrange
        User user = DummyUserDataUtil.createUser_1();
        UserResponseDto expectedUserResponse = DummyUserDataUtil.createUserResponseDto_1();

        // Act
        UserResponseDto userResponseDto = usersMapper.entityToResponseDto(user);

        // Assert
        assertEquals(expectedUserResponse.getId(), userResponseDto.getId());
        assertEquals(expectedUserResponse.getFullName(), userResponseDto.getFullName());

    }

    @Test
    void test_UserRequestToUser() {

        // Arrange
        UserRequestDto userRequestDto = DummyUserDataUtil.createUserRequestDto_1();
        User expectedUser = DummyUserDataUtil.createUser_1();

        // Act
        User user = usersMapper.requestDtoToEntity(userRequestDto);

        // Assert
        assertEquals(expectedUser.getFullName(), user.getFullName());

    }
}