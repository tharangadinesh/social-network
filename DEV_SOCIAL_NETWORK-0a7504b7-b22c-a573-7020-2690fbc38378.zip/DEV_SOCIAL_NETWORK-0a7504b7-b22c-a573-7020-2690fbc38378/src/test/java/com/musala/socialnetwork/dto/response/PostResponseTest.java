package com.musala.socialnetwork.dto.response;

import com.musala.socialnetwork.utility.DummyPostDataUtil;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PostResponseTest {

    @Test
    void test_NoArgsConstructor(){

        PostResponseDto postResponse = new PostResponseDto();

        assertNull(postResponse.getId());
    }

    @Test
    void test_AllArgsConstructor(){

        PostResponseDto resourceSkillRequestDTO = DummyPostDataUtil.createPostResponseDto_1();

        assertEquals(1L, resourceSkillRequestDTO.getId());
    }

    @Test
    void test_ToString() {

        //Act
        PostResponseDto postResponseDto = DummyPostDataUtil.createPostResponseDto_1();
        String expectedToString = "PostResponseDto(id=1, userId=1, text=Sample Post, visibility=PUBLIC, postedOn=2024-03-01 00:00:00, likeCount=1, isLiked=false)";

        // Assert
        assertEquals(expectedToString, postResponseDto.toString());
    }

    @Test
    void test_EqualsAndHashCode() {

        PostResponseDto postResponse_1 = DummyPostDataUtil.createPostResponseDto_1();
        PostResponseDto postResponse_2 = DummyPostDataUtil.createPostResponseDto_1();
        PostResponseDto postResponse_3 = DummyPostDataUtil.createPostResponseDto_2();

        assertEquals(postResponse_1, postResponse_2);
        assertNotEquals(postResponse_1, postResponse_3);
        assertNotEquals(null, postResponse_1);

        assertEquals(postResponse_1.hashCode(), postResponse_2.hashCode());
        assertNotEquals(postResponse_1.hashCode(), postResponse_3.hashCode());
    }
}