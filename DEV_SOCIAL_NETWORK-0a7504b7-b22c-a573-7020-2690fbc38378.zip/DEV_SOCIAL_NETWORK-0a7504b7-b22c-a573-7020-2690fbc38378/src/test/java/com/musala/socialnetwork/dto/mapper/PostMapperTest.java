package com.musala.socialnetwork.dto.mapper;

import com.musala.socialnetwork.dto.request.PostRequestDto;
import com.musala.socialnetwork.dto.response.PostResponseDto;
import com.musala.socialnetwork.entity.Post;
import com.musala.socialnetwork.mapper.PostMapper;
import com.musala.socialnetwork.utility.DummyPostDataUtil;
import com.musala.socialnetwork.utility.LocalDateTimeUtil;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class PostMapperTest {
    @InjectMocks
    private PostMapper postsMapper;

    private AutoCloseable closeable;

    @BeforeEach
    public void openMocks() {
        closeable = MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    public void releaseMocks() throws Exception {
        closeable.close();
    }

    @Test
    void test_PostToPostResponse() {

        // Arrange
        Post post = DummyPostDataUtil.createPost_1();

        // Act
        PostResponseDto postResponseDto = postsMapper.entityToResponseDto(post);

        // Assert
        assertEquals(post.getId(), postResponseDto.getId());
        assertEquals(post.getText(), postResponseDto.getText());
        assertEquals(LocalDateTimeUtil.formatDateTime(post.getCreatedOn()), postResponseDto.getPostedOn());
        assertEquals(post.getUser().getId(), postResponseDto.getUserId());
        assertEquals(post.getVisibility(), postResponseDto.getVisibility());
        assertEquals(post.getLikeCount(), postResponseDto.getLikeCount());

    }

    @Test
    void test_PostRequestToPost() {

        // Arrange
        PostRequestDto postRequestDto = DummyPostDataUtil.createPostRequestDto_1();

        // Act
        Post post = postsMapper.requestDtoToEntity(postRequestDto);

        // Assert
        assertEquals(postRequestDto.getText(), post.getText());
        assertEquals(postRequestDto.getVisibility(), post.getVisibility());
    }

    @Test
    void test_PostListToResponseList() {

        // Arrange
        List<Post> postList = List.of(
                DummyPostDataUtil.createPost_1(),
                DummyPostDataUtil.createPost_2()
        );

        // Act
        List<PostResponseDto> postResponseDtoList = postsMapper.entityListToResponseList(postList);

        // Assert
        assertEquals(postResponseDtoList.size(), postList.size());

    }
}