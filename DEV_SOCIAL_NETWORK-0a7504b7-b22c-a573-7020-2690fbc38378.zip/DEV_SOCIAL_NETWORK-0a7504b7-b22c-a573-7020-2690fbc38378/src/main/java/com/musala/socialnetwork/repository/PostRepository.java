package com.musala.socialnetwork.repository;

import com.musala.socialnetwork.entity.Post;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Set;

@Repository
public interface PostRepository extends JpaRepository<Post, Long> {

    @Query("FROM Post WHERE user.id = :userId ORDER BY createdOn DESC")
    Set<Post> findAllByUser(@Param("userId") Long userId);

    @Query("FROM Post WHERE user.id = :userId and visibility = 1 ORDER BY createdOn DESC")
    Set<Post> findAllPublicByUser(@Param("userId") Long userId);
}
