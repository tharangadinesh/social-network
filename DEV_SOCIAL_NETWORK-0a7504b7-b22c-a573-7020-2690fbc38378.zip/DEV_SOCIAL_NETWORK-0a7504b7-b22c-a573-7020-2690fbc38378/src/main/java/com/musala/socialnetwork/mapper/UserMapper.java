package com.musala.socialnetwork.mapper;

import com.musala.socialnetwork.dto.request.UserRequestDto;
import com.musala.socialnetwork.dto.response.UserResponseDto;
import com.musala.socialnetwork.entity.User;
import org.springframework.stereotype.Component;

@Component
public class UserMapper extends GenericMapper<UserRequestDto, UserResponseDto, User>{
    @Override
    public User requestDtoToEntity(UserRequestDto userRequestDto) {
        return User.builder()
                .fullName(userRequestDto.getFullName())
                .build();
    }

    @Override
    public UserResponseDto entityToResponseDto(User user) {
        return UserResponseDto.builder()
                .id(user.getId())
                .fullName(user.getFullName())
                .build();
    }
}
