package com.musala.socialnetwork.exception;

public class DataConflictException extends RuntimeException{
    public DataConflictException(String message) {
        super(message);
    }
}

