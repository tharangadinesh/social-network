package com.musala.socialnetwork.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@Table(name = Follower.TABLE)
@Entity
@SQLDelete(sql = "UPDATE " + Follower.TABLE + " SET deleted = true WHERE id=?")
@Where(clause = "deleted=false")
public class Follower extends BaseEntity {

    public static final String TABLE = "tbl_follower";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "follower_id")
    private User follower;
}
