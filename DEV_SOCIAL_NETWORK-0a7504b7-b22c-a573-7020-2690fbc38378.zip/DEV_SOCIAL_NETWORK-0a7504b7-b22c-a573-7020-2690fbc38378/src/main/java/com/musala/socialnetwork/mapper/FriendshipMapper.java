package com.musala.socialnetwork.mapper;

import com.musala.socialnetwork.dto.response.FriendshipResponseDto;
import com.musala.socialnetwork.entity.Friend;
import org.springframework.stereotype.Component;

@Component
public class FriendshipMapper {

    public FriendshipResponseDto entityToResponseDto(Friend friend) {
        return FriendshipResponseDto.builder()
                .id(friend.getId())
                .friendId(friend.getFriend().getId())
                .userId(friend.getUser().getId())
                .build();
    }
}
