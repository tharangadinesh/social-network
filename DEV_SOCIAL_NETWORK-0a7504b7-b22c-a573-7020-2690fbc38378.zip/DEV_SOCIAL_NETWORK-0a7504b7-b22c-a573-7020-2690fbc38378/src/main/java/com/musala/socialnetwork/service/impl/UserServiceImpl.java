package com.musala.socialnetwork.service.impl;

import com.musala.socialnetwork.dto.request.UserRequestDto;
import com.musala.socialnetwork.dto.response.UserResponseDto;
import com.musala.socialnetwork.entity.User;
import com.musala.socialnetwork.exception.DataConflictException;
import com.musala.socialnetwork.mapper.UserMapper;
import com.musala.socialnetwork.repository.UserRepository;
import com.musala.socialnetwork.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import java.util.Optional;

@Service
@Slf4j
@Validated
@Transactional
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final UserMapper userMapper;

    public UserServiceImpl(UserRepository userRepository,
                           UserMapper userMapper) {
        this.userRepository = userRepository;
        this.userMapper = userMapper;
    }

    /**
     * Creates a new user based on the provided UserRequestDto.
     *
     * @param userRequestDto The UserRequestDto object containing the data for the new user.
     * @return UserResponseDto representing the created user.
     * @throws DataConflictException if a user with the same full name already exists.
     */
    @Override
    public UserResponseDto createUser(UserRequestDto userRequestDto) {

        Optional<User> optionalLocation = userRepository.findByFullName(userRequestDto.getFullName());
        if (optionalLocation.isPresent()) {
            String msg = String.format("User %s is already exist.", userRequestDto.getFullName());
            log.warn(msg);
            throw new DataConflictException(msg);
        }

        User user = userMapper.requestDtoToEntity(userRequestDto);
        User savedUser = userRepository.save(user);

        return userMapper.entityToResponseDto(savedUser);
    }
}
