package com.musala.socialnetwork.service.impl;

import com.musala.socialnetwork.dto.response.PostResponseDto;
import com.musala.socialnetwork.entity.BaseEntity;
import com.musala.socialnetwork.entity.Post;
import com.musala.socialnetwork.entity.User;
import com.musala.socialnetwork.mapper.PostMapper;
import com.musala.socialnetwork.repository.PostRepository;
import com.musala.socialnetwork.service.WallService;
import com.musala.socialnetwork.service.handler.UserHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import java.util.Comparator;
import java.util.List;
import java.util.Set;

@Service
@Slf4j
@Validated
@Transactional
public class WallServiceImpl implements WallService {

    private final PostRepository postRepository;
    private final UserHandler userHandler;
    private final PostMapper postMapper;

    public WallServiceImpl(PostRepository postRepository,
                           UserHandler userHandler,
                           PostMapper postMapper) {
        this.postRepository = postRepository;
        this.userHandler = userHandler;
        this.postMapper = postMapper;
    }

    /**
     * Retrieves posts made by a specific user, their friends, and people they follow.
     *
     * @param userId The ID of the user for whom posts are to be fetched.
     * @return List of PostResponseDto objects representing the fetched posts.
     */
    @Override
    public List<PostResponseDto> getPostsByUser(Long userId) {

        Set<Post> posts = postRepository.findAllByUser(userId);

        User user = userHandler.findById(userId);

        user.getFriends().forEach(friend -> posts.addAll( postRepository.findAllByUser(friend.getFriend().getId()) ));

        user.getFollowers().forEach(follower -> posts.addAll( postRepository.findAllPublicByUser( follower.getFollower().getId() ) ));

        return postMapper.entityListToResponseList( posts.stream()
                .sorted(Comparator.comparing(BaseEntity::getCreatedOn))
                .toList() );

    }
}
