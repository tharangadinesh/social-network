package com.musala.socialnetwork.service.handler;

import com.musala.socialnetwork.entity.Post;
import com.musala.socialnetwork.exception.PostNotFoundException;
import com.musala.socialnetwork.repository.PostRepository;
import org.springframework.stereotype.Component;

@Component
public class PostHandler {

    private final PostRepository postRepository;

    public PostHandler(PostRepository postRepository) {
        this.postRepository = postRepository;
    }

    public Post findById(Long postId){
        return postRepository.findById(postId)
                .orElseThrow(() -> new PostNotFoundException("Could not find the postId: {postId}"));
    }

    public Post save(Post post){
        return postRepository.save(post);
    }
}
