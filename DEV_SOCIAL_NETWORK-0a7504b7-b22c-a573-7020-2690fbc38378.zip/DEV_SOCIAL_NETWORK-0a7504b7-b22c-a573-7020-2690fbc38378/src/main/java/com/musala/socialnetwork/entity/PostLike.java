package com.musala.socialnetwork.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@Table(name = PostLike.TABLE)
@Entity
@SQLDelete(sql = "UPDATE " + PostLike.TABLE + " SET deleted = true WHERE id=?")
@Where(clause = "deleted=false")
//@EntityListeners({PostLikeListener.class})
public class PostLike extends BaseEntity{

    public static final String TABLE = "tbl_post_like";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "post_id")
    private Post post;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

}
