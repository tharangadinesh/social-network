package com.musala.socialnetwork.service;

import com.musala.socialnetwork.dto.response.FollowershipResponseDto;

public interface FollowershipService {

    /**
     * Adds a follower to a user.
     *
     * @param userId     The ID of the user to be followed.
     * @param followerId The ID of the user initiating the follow action.
     * @return FollowershipResponseDto representing the added follower relationship.
     */
    FollowershipResponseDto addFollower(Long userId, Long followerId);

}
