package com.musala.socialnetwork.dto;

public abstract class BaseDto {
}
