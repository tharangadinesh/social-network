package com.musala.socialnetwork.exception;

public class UserNotFoundException extends ObjectNotFoundException{
    public UserNotFoundException(String message) {
        super(message);
    }
}
