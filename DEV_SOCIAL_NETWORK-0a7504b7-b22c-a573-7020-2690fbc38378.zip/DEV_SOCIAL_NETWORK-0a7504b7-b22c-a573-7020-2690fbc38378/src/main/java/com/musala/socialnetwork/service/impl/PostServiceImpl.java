package com.musala.socialnetwork.service.impl;

import com.musala.socialnetwork.dto.request.PostRequestDto;
import com.musala.socialnetwork.dto.response.PostResponseDto;
import com.musala.socialnetwork.entity.Post;
import com.musala.socialnetwork.entity.User;
import com.musala.socialnetwork.mapper.PostMapper;
import com.musala.socialnetwork.repository.PostRepository;
import com.musala.socialnetwork.service.PostService;
import com.musala.socialnetwork.service.handler.UserHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

@Service
@Slf4j
@Validated
@Transactional
public class PostServiceImpl implements PostService {

    private final PostRepository postRepository;
    private final UserHandler userHandler;
    private final PostMapper postMapper;

    public PostServiceImpl(PostRepository postRepository,
                           UserHandler userHandler,
                           PostMapper postMapper) {
        this.postRepository = postRepository;
        this.userHandler = userHandler;
        this.postMapper = postMapper;
    }

    /**
     * Creates a new post based on the provided PostRequestDto.
     *
     * @param postRequestDto The PostRequestDto object containing the data for the new post.
     * @return PostResponseDto representing the created post.
     */
    @Override
    public PostResponseDto createPost(PostRequestDto postRequestDto) {

        Post post = postMapper.requestDtoToEntity(postRequestDto);

        User user = userHandler.findById(postRequestDto.getUserId());
        post.setUser(user);

        Post savedPost = postRepository.save(post);
        return postMapper.entityToResponseDto(savedPost);

    }


}
