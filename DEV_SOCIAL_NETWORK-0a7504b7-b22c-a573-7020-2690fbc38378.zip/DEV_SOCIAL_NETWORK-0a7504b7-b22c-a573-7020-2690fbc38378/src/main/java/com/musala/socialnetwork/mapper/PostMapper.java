package com.musala.socialnetwork.mapper;

import com.musala.socialnetwork.dto.request.PostRequestDto;
import com.musala.socialnetwork.dto.response.PostResponseDto;
import com.musala.socialnetwork.entity.Post;
import com.musala.socialnetwork.utility.LocalDateTimeUtil;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class PostMapper extends GenericMapper<PostRequestDto, PostResponseDto, Post>{
    @Override
    public Post requestDtoToEntity(PostRequestDto postRequestDto) {
        return Post.builder()
                .text(postRequestDto.getText())
                .visibility(postRequestDto.getVisibility())
                .build();
    }

    @Override
    public PostResponseDto entityToResponseDto(Post post) {
        return PostResponseDto.builder()
                .id(post.getId())
                .text(post.getText())
                .userId(post.getUser().getId())
                .visibility(post.getVisibility())
                .postedOn(LocalDateTimeUtil.formatDateTime(post.getCreatedOn()))
                .likeCount(post.getLikeCount())
                .build();
    }

    public List<PostResponseDto> entityListToResponseList(List<Post> posts) {
        return posts.stream()
                .map(this::entityToResponseDto)
                .toList();
    }
}
