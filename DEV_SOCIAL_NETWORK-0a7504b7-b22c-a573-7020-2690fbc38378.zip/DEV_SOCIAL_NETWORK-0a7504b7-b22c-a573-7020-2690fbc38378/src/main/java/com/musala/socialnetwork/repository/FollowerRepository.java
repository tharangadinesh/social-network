package com.musala.socialnetwork.repository;

import com.musala.socialnetwork.entity.Follower;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface FollowerRepository extends JpaRepository<Follower, Long> {
    @Query("FROM Follower WHERE user.id = :userId AND follower.id = :followerId")
    Optional<Follower> existsByUserAndFollower(@Param("userId") Long userId, @Param("followerId") Long followerId);
}
