package com.musala.socialnetwork.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@Table(name = Friend.TABLE)
@Entity
@SQLDelete(sql = "UPDATE " + Friend.TABLE + " SET deleted = true WHERE id=?")
@Where(clause = "deleted=false")
public class Friend extends BaseEntity {

    public static final String TABLE = "tbl_friend";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "friend_id")
    private User friend;
}
