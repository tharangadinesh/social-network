package com.musala.socialnetwork.service;

import com.musala.socialnetwork.dto.request.PostRequestDto;
import com.musala.socialnetwork.dto.response.PostResponseDto;

public interface PostService {

    /**
     * Creates a new post based on the provided PostRequestDto.
     *
     * @param postRequestDto The PostRequestDto object containing the data for the new post.
     * @return PostResponseDto representing the created post.
     */
    PostResponseDto createPost( PostRequestDto postRequestDto);

}
