package com.musala.socialnetwork.mapper;

import com.musala.socialnetwork.dto.response.FollowershipResponseDto;
import com.musala.socialnetwork.entity.Follower;
import org.springframework.stereotype.Component;

@Component
public class FollowershipMapper{

    public FollowershipResponseDto entityToResponseDto(Follower follower) {
        return FollowershipResponseDto.builder()
                .id(follower.getId())
                .followerId(follower.getFollower().getId())
                .userId(follower.getUser().getId())
                .build();
    }
}
