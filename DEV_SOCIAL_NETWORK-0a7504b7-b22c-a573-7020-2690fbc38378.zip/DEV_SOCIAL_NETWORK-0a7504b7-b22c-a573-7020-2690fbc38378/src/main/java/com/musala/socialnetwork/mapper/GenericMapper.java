package com.musala.socialnetwork.mapper;

import com.musala.socialnetwork.dto.BaseDto;
import com.musala.socialnetwork.entity.BaseEntity;

public abstract class GenericMapper<requestDto extends BaseDto, responseDto extends BaseDto, entity extends BaseEntity> {

    public abstract entity requestDtoToEntity(requestDto requestDto);

    public abstract responseDto entityToResponseDto(entity entity);

}
