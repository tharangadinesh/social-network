package com.musala.socialnetwork.controller;

import com.musala.socialnetwork.dto.response.PostResponseDto;
import com.musala.socialnetwork.dto.response.common.ApiResponse;
import com.musala.socialnetwork.service.WallService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/v1/walls")
public class WallRestController {

    private final WallService wallService;

    public WallRestController(WallService wallService) {
        this.wallService = wallService;
    }

    /**
     * Endpoint to fetch posts made by a specific user, their friends, and people they follow.
     *
     * @param userId The ID of the user for whom posts are to be fetched.
     * @return ResponseEntity containing an ApiResponse with a list of PostResponseDto objects and a success message.
     */
    @Operation(description = "Api for get posts by a user", summary = "Fetching post by user")
    @GetMapping("/{userId}")
    public ResponseEntity<ApiResponse<List<PostResponseDto>>> getPostsByUser(@Valid @PathVariable Long userId) {

        List<PostResponseDto> postResponseDtoList = wallService.getPostsByUser(userId);
        ApiResponse<List<PostResponseDto>> apiResponse = ApiResponse.<List<PostResponseDto>>builder()
                .status(HttpStatus.OK)
                .message("A list of all the posts made by the user, their friends, and people they follow, sorted by timestamp descending")
                .success(true)
                .data(postResponseDtoList)
                .build();

        return ResponseEntity
                .status(HttpStatus.OK)
                .body(apiResponse);
    }
}
