package com.musala.socialnetwork.service;

import com.musala.socialnetwork.dto.response.FriendshipResponseDto;

public interface FriendshipService {

    /**
     * Adds a friend to a user.
     *
     * @param userId     The ID of the user to be followed.
     * @param friendId The ID of the user initiating the follow action.
     * @return FriendshipResponseDto representing the added friend relationship.
     */
    FriendshipResponseDto addFriend(Long userId, Long friendId);

}
