package com.musala.socialnetwork.controller;

import com.musala.socialnetwork.dto.request.UserRequestDto;
import com.musala.socialnetwork.dto.response.FollowershipResponseDto;
import com.musala.socialnetwork.dto.response.FriendshipResponseDto;
import com.musala.socialnetwork.dto.response.UserResponseDto;
import com.musala.socialnetwork.dto.response.common.ApiResponse;
import com.musala.socialnetwork.service.FollowershipService;
import com.musala.socialnetwork.service.FriendshipService;
import com.musala.socialnetwork.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api/v1/users")
public class UserRestController {
    private final UserService userService;
    private final FriendshipService friendshipService;
    private final FollowershipService followershipService;

    public UserRestController(UserService userService,
                              FriendshipService friendshipService,
                              FollowershipService followershipService) {
        this.userService = userService;
        this.friendshipService = friendshipService;
        this.followershipService = followershipService;
    }

    /**
     * Endpoint to create a new user based on the provided UserRequestDto.
     *
     * @param userRequestDto The UserRequestDto object containing the data for the new user.
     * @return ResponseEntity containing an ApiResponse with the created UserResponseDto and a success message.
     */
    @Operation(description = "Api for Create a User", summary = "Create a User")
    @PostMapping
    public ResponseEntity<ApiResponse<UserResponseDto>> createUser(@Valid @RequestBody UserRequestDto userRequestDto) {
        UserResponseDto userResponseDto = userService.createUser(userRequestDto);
        ApiResponse<UserResponseDto> apiResponse = ApiResponse.<UserResponseDto>builder()
                .status(HttpStatus.CREATED)
                .message("A new user has been created successfully.")
                .success(true)
                .data(userResponseDto)
                .build();

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(apiResponse);
    }

    /**
     * Endpoint to create a friendship between two users.
     *
     * @param userId    The ID of the user initiating the friendship.
     * @param friendId  The ID of the user to become friends with.
     * @return ResponseEntity containing an ApiResponse with the created FriendshipResponseDto and a success message.
     */
    @Operation(description = "Api for Create a friendship", summary = "Create a friendship")
    @PostMapping("/{userId}/friends/{friendId}")
    public ResponseEntity<ApiResponse<FriendshipResponseDto>> addFriend(@Valid @PathVariable("userId") Long userId,
                                                                  @Valid @PathVariable("friendId") Long friendId) {
        FriendshipResponseDto friendshipResponseDto = friendshipService.addFriend(userId, friendId);
        ApiResponse<FriendshipResponseDto> apiResponse = ApiResponse.<FriendshipResponseDto>builder()
                .status(HttpStatus.CREATED)
                .message("Successfully added the friendship relation.")
                .success(true)
                .data(friendshipResponseDto)
                .build();

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(apiResponse);
    }

    /**
     * Endpoint to add a follower to a user.
     *
     * @param userId      The ID of the user to be followed.
     * @param followerId  The ID of the user initiating the follow action.
     * @return ResponseEntity containing an ApiResponse with the created FollowershipResponseDto and a success message.
     */
    @Operation(description = "Api for add a follower", summary = "Add a follower")
    @PostMapping("/{userId}/follower/{followerId}")
    public ResponseEntity<ApiResponse<FollowershipResponseDto>> addFollower(@Valid @PathVariable("userId") Long userId,
                                                                            @Valid @PathVariable("followerId") Long followerId) {
        FollowershipResponseDto followershipResponseDto = followershipService.addFollower(userId, followerId);
        ApiResponse<FollowershipResponseDto> apiResponse = ApiResponse.<FollowershipResponseDto>builder()
                .status(HttpStatus.CREATED)
                .message("Successfully added the follower relation.")
                .success(true)
                .data(followershipResponseDto)
                .build();

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(apiResponse);
    }

}
