package com.musala.socialnetwork.controller;

import com.musala.socialnetwork.dto.request.PostRequestDto;
import com.musala.socialnetwork.dto.response.PostResponseDto;
import com.musala.socialnetwork.dto.response.common.ApiResponse;
import com.musala.socialnetwork.service.PostLikeService;
import com.musala.socialnetwork.service.PostService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api/v1/posts")
public class PostRestController {

    private final PostService postService;
    private final PostLikeService postLikeService;

    public PostRestController(PostService postService,
                              PostLikeService postLikeService) {
        this.postService = postService;
        this.postLikeService = postLikeService;
    }

    /**
     * Endpoint to create a new post based on the provided PostRequestDto.
     *
     * @param postRequestDto The PostRequestDto object containing the data for the new post.
     * @return ResponseEntity containing an ApiResponse with the created PostResponseDto and a success message.
     */
    @Operation(description = "Api for Create a Post", summary = "Create a Post")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "200",
                    description = "The post has been created successfully",
                    content = {@Content(mediaType = "application/json", schema = @Schema(implementation = PostResponseDto.class))}),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "400",
                    description = "The post request was invalid",
                    content = @Content),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "500",
                    description = "Internal server error",
                    content = @Content),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "404",
                    description = "User not found",
                    content = @Content)})
    @PostMapping
    public ResponseEntity<ApiResponse<PostResponseDto>> createPost(@Valid @RequestBody PostRequestDto postRequestDto) {
        PostResponseDto postResponseDto = postService.createPost(postRequestDto);
        ApiResponse<PostResponseDto> apiResponse = new ApiResponse<>(
                HttpStatus.CREATED,
                "The post has been created successfully",
                Boolean.TRUE,
                postResponseDto
        );
        return ResponseEntity.ok(apiResponse);
    }

    /**
     * Endpoint to like a specific post.
     *
     * @param postId The ID of the post to be liked.
     * @param userId The ID of the user performing the like action.
     */
    @Operation(description = "Api for Like a Post", summary = "Like a Post")
    @PostMapping("/{postId}/like")
    public void likePost(@PathVariable Long postId,
                         @RequestParam Long userId) {
        postLikeService.likePost(postId, userId);
    }

    /**
     * Endpoint to unlike a specific post.
     *
     * @param postId The ID of the post to be unliked.
     * @param userId The ID of the user performing the unlike action.
     */
    @Operation(description = "Api for Unlike a Post", summary = "Unlike a Post")
    @PostMapping("/{postId}/unlike")
    public void unlikePost(@PathVariable Long postId,
                           @RequestParam Long userId) {
        postLikeService.unlikePost(postId, userId);
    }
}
