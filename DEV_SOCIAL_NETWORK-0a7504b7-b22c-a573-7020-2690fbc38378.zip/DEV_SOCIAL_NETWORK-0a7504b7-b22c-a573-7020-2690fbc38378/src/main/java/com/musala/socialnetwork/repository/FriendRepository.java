package com.musala.socialnetwork.repository;

import com.musala.socialnetwork.entity.Friend;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface FriendRepository extends JpaRepository<Friend, Long> {

    @Query("FROM Friend WHERE user.id = :userId AND friend.id = :friendId")
    Optional<Friend> existsByUserAndFriend(@Param("userId") Long userId, @Param("friendId") Long friendId);

}
