package com.musala.socialnetwork.dto.request;

import com.musala.socialnetwork.dto.BaseDto;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserRequestDto extends BaseDto {

    @NotBlank(message = "Full Name cannot be empty")
    private String fullName;

}
