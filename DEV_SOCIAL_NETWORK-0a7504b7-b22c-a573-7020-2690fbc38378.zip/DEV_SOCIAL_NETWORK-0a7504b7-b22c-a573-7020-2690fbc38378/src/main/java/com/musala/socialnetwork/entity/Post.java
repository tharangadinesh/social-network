package com.musala.socialnetwork.entity;

import com.musala.socialnetwork.constant.PostVisibility;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@Data
@Table(name = Post.TABLE)
@Entity
@SQLDelete(sql = "UPDATE " + Post.TABLE + " SET deleted = true WHERE id=?")
@Where(clause = "deleted=false")
public class Post extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "text")
    private String text;

    @Column(name = "visibility")
    private PostVisibility visibility;

    @Column(name = "like_count")
    @Builder.Default
    private Integer likeCount = 0;

    @ManyToOne(targetEntity = User.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User user;

    public static final String TABLE = "tbl_post";
    @OneToMany(mappedBy = "post", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<PostLike> postLikes;
}
