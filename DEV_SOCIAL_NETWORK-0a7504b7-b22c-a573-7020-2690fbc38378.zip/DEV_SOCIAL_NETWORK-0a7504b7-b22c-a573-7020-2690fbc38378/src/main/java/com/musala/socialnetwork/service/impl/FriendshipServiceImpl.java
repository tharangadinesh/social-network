package com.musala.socialnetwork.service.impl;

import com.musala.socialnetwork.dto.response.FriendshipResponseDto;
import com.musala.socialnetwork.entity.Friend;
import com.musala.socialnetwork.entity.User;
import com.musala.socialnetwork.mapper.FriendshipMapper;
import com.musala.socialnetwork.repository.FriendRepository;
import com.musala.socialnetwork.service.FriendshipService;
import com.musala.socialnetwork.service.handler.UserHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

@Service
@Slf4j
@Validated
@Transactional
public class FriendshipServiceImpl implements FriendshipService {

    private final UserHandler userHandler;
    private final FriendRepository friendRepository;
    private final FriendshipMapper friendshipMapper;

    public FriendshipServiceImpl(UserHandler userHandler,
                                 FriendRepository friendRepository,
                                 FriendshipMapper friendshipMapper) {
        this.userHandler = userHandler;
        this.friendRepository = friendRepository;
        this.friendshipMapper = friendshipMapper;
    }

    /**
     * Adds a friend to a user.
     *
     * @param userId     The ID of the user to be followed.
     * @param friendId The ID of the user initiating the follow action.
     * @return FriendshipResponseDto representing the added friend relationship.
     * @throws IllegalArgumentException  if userId or friendId is null.
     * @throws IllegalStateException     if the users are already friends.
     */
    public FriendshipResponseDto addFriend(Long userId, Long friendId) {

        if (userId == null || friendId == null) {
            throw new IllegalArgumentException("User or friend cannot be null");
        }

        User friend = userHandler.findById(friendId);
        User user = userHandler.findById(userId);

        // Check if users are already friends
        if (areFriends(user, friend)) {
            throw new IllegalStateException("Users are already friends");
        }

        // Add friendship relationship
        Friend friendship = Friend.builder()
                .friend(friend)
                .user(user)
                .build();

        Friend savedFriend = friendRepository.save(friendship);

        return friendshipMapper.entityToResponseDto(savedFriend);
    }

    public boolean areFriends(User user, User friend) {
        // Check if there is a friendship relationship between the two users
        return friendRepository.existsByUserAndFriend(user.getId(), friend.getId()).isPresent();
    }

}
