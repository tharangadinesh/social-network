package com.musala.socialnetwork.service.handler;

import com.musala.socialnetwork.entity.User;
import com.musala.socialnetwork.exception.UserNotFoundException;
import com.musala.socialnetwork.repository.UserRepository;
import org.springframework.stereotype.Component;

@Component
public class UserHandler {

    private final UserRepository userRepository;

    public UserHandler(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public User findById(Long userId){
        return userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException("Could not find the userId: {userId}"));
    }
}
