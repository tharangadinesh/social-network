package com.musala.socialnetwork.service;

import com.musala.socialnetwork.dto.response.PostResponseDto;

import java.util.List;

public interface WallService {

    /**
     * Retrieves posts made by a specific user, their friends, and people they follow.
     *
     * @param userId The ID of the user for whom posts are to be fetched.
     * @return List of PostResponseDto objects representing the fetched posts.
     */
    List<PostResponseDto> getPostsByUser(Long userId);

}
