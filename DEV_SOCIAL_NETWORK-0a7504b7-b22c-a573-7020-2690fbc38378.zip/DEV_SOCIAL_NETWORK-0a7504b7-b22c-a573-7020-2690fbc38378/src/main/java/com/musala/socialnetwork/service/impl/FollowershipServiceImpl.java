package com.musala.socialnetwork.service.impl;

import com.musala.socialnetwork.dto.response.FollowershipResponseDto;
import com.musala.socialnetwork.entity.Follower;
import com.musala.socialnetwork.entity.User;
import com.musala.socialnetwork.mapper.FollowershipMapper;
import com.musala.socialnetwork.repository.FollowerRepository;
import com.musala.socialnetwork.service.FollowershipService;
import com.musala.socialnetwork.service.handler.UserHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

@Service
@Slf4j
@Validated
@Transactional
public class FollowershipServiceImpl implements FollowershipService {

    private final UserHandler userHandler;
    private final FollowerRepository followerRepository;
    private final FollowershipMapper followershipMapper;

    public FollowershipServiceImpl(UserHandler userHandler,
                                   FollowerRepository followerRepository,
                                   FollowershipMapper followershipMapper) {
        this.userHandler = userHandler;
        this.followerRepository = followerRepository;
        this.followershipMapper = followershipMapper;
    }

    /**
     * Adds a follower to a user.
     *
     * @param userId     The ID of the user to be followed.
     * @param followerId The ID of the user initiating the follow action.
     * @return FollowershipResponseDto representing the added follower relationship.
     * @throws IllegalArgumentException  if userId or followerId is null.
     * @throws IllegalStateException     if the users are already followers.
     */
    public FollowershipResponseDto addFollower(Long userId, Long followerId) {

        if (userId == null || followerId == null) {
            throw new IllegalArgumentException("User or follower cannot be null");
        }

        User user = userHandler.findById(userId);
        User followingUser = userHandler.findById(followerId);

        // Check if users are already followers
        if (areFollowers(user, followingUser)) {
            throw new IllegalStateException("Users are already followers");
        }

        // Add followership relationship
        Follower follower = Follower.builder()
                .follower(followingUser)
                .user(user)
                .build();

        Follower savedFollower = followerRepository.save(follower);

        return followershipMapper.entityToResponseDto(savedFollower);
    }

    public boolean areFollowers(User user, User follower) {
        // Check if there is a followership relationship between the two users
        return followerRepository.existsByUserAndFollower(user.getId(), follower.getId()).isPresent();
    }

}
