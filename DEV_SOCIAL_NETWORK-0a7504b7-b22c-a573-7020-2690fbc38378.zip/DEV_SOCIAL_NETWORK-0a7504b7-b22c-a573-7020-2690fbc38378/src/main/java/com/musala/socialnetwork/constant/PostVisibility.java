package com.musala.socialnetwork.constant;

public enum PostVisibility {

    PRIVATE,
    PUBLIC;
}
