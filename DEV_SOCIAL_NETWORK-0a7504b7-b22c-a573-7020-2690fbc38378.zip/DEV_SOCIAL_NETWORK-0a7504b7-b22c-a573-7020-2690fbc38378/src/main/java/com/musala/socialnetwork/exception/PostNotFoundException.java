package com.musala.socialnetwork.exception;

public class PostNotFoundException extends ObjectNotFoundException{
    public PostNotFoundException(String message) {
        super(message);
    }
}
