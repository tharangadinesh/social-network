package com.musala.socialnetwork.exception;

import com.musala.socialnetwork.dto.response.common.ErrorResponseDTO;
import com.musala.socialnetwork.utility.LocalDateTimeUtil;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.ValidationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import java.nio.file.AccessDeniedException;
import java.util.stream.Collectors;

@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    @ExceptionHandler(AccessDeniedException.class)
    public final ResponseEntity<Object> handleAccessDeniedException(Exception ex, WebRequest request) {
        return new ResponseEntity<>(
                new ErrorResponseDTO<>(
                        HttpStatus.UNAUTHORIZED,
                        ex.getMessage(),
                        LocalDateTimeUtil.getCurrentDateTime(),
                        request.getDescription(false)),
                HttpStatus.UNAUTHORIZED);
    }

    @ExceptionHandler(ObjectNotFoundException.class)
    public final ResponseEntity<Object> handleNotFoundException(Exception ex, WebRequest request) {
        log.error(ex.getMessage(), ex);
        return new ResponseEntity<>(
                new ErrorResponseDTO<>(
                        HttpStatus.NOT_FOUND,
                        ex.getMessage(),
                        LocalDateTimeUtil.getCurrentDateTime(),
                        request.getDescription(false)),
                HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(CommonServerException.class)
    public final ResponseEntity<Object> handleCommonServerException(Exception ex, WebRequest request) {
        return new ResponseEntity<>(
                new ErrorResponseDTO<>(
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        ex.getMessage(),
                        LocalDateTimeUtil.getCurrentDateTime(),
                        request.getDescription(false)),
                HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(DataConflictException.class)
    public final ResponseEntity<Object> handleDataConflictException(Exception ex, WebRequest request) {
        log.error(ex.getMessage(), ex);
        return new ResponseEntity<>(
                new ErrorResponseDTO<>(HttpStatus.CONFLICT,
                        ex.getMessage(),
                        LocalDateTimeUtil.getCurrentDateTime(),
                        request.getDescription(false)),
                HttpStatus.CONFLICT);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Object> handleMethodArgumentNotValidException(MethodArgumentNotValidException ex, WebRequest request) {
        String exceptionMessage = extractViolationsFromException(ex);
        return new ResponseEntity<>(
                new ErrorResponseDTO<>(
                        HttpStatus.BAD_REQUEST,
                        exceptionMessage,
                        LocalDateTimeUtil.getCurrentDateTime(),
                        request.getDescription(false)),
                HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<Object> handleMethodArgumentTypeMismatchException(MethodArgumentTypeMismatchException ex, WebRequest request) {
        String errorMessage = "Invalid argument type for parameter '" + ex.getName() + "'";
        if (ex.getRequiredType() != null) {
            errorMessage += " Expected type: " + ex.getRequiredType().getSimpleName();
        }
        return new ResponseEntity<>(
                new ErrorResponseDTO<>(HttpStatus.BAD_REQUEST,
                        errorMessage,
                        LocalDateTimeUtil.getCurrentDateTime(),
                        request.getDescription(false)),
                HttpStatus.BAD_REQUEST);
    }

    @ResponseBody
    @ExceptionHandler(value = {ValidationException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<Object> handleValidationException(ValidationException validationException, WebRequest request) {

        String errorMessage;

        if (validationException instanceof ConstraintViolationException constraintViolationException) {
            errorMessage = extractViolationsFromException(constraintViolationException);
        } else {
            errorMessage = validationException.getMessage();
        }

        log.error(errorMessage, validationException);

        ErrorResponseDTO<Object> errorResponseDTO = new ErrorResponseDTO<>(
                HttpStatus.BAD_REQUEST,
                errorMessage,
                LocalDateTimeUtil.getCurrentDateTime(),
                request.getDescription(false));

        return new ResponseEntity<>(errorResponseDTO, HttpStatus.BAD_REQUEST);
    }

    private String extractViolationsFromException(ConstraintViolationException constraintViolationException) {
        return constraintViolationException.getConstraintViolations()
                .stream()
                .map(ConstraintViolation::getMessage)
                .collect(Collectors.joining("--"));
    }

    private String extractViolationsFromException(MethodArgumentNotValidException methodArgumentNotValidException) {
        return methodArgumentNotValidException.getFieldErrors()
                .stream()
                .map(field -> field.getField() + ": " + field.getDefaultMessage())
                .collect(Collectors.joining("--"));
    }
}
