package com.musala.socialnetwork.dto.response;

import com.musala.socialnetwork.dto.BaseDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FollowershipResponseDto extends BaseDto {

    private Long id;
    private Long userId;
    private Long followerId;

}
