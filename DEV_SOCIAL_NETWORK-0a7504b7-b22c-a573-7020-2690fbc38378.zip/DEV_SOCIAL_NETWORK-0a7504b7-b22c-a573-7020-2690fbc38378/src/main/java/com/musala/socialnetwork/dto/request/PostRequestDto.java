package com.musala.socialnetwork.dto.request;

import com.musala.socialnetwork.constant.PostVisibility;
import com.musala.socialnetwork.dto.BaseDto;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PostRequestDto extends BaseDto {

    @NotNull(message = "User Id cannot be null or empty")
    private Long userId;

    @NotBlank(message = "Text cannot be empty")
    private String text;

    @NotNull(message = "Visibility cannot be null or empty")
    private PostVisibility visibility;

}
