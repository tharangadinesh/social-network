package com.musala.socialnetwork.service.impl;

import com.musala.socialnetwork.entity.Post;
import com.musala.socialnetwork.entity.PostLike;
import com.musala.socialnetwork.entity.User;
import com.musala.socialnetwork.repository.PostLikeRepository;
import com.musala.socialnetwork.service.PostLikeService;
import com.musala.socialnetwork.service.handler.PostHandler;
import com.musala.socialnetwork.service.handler.UserHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import java.util.Optional;

@Service
@Slf4j
@Validated
@Transactional
public class PostLikeServiceImpl implements PostLikeService {

    private final UserHandler userHandler;
    private final PostHandler postHandler;
    private final PostLikeRepository postLikeRepository;

    public PostLikeServiceImpl(UserHandler userHandler,
                               PostHandler postHandler,
                               PostLikeRepository postLikeRepository) {
        this.userHandler = userHandler;
        this.postHandler = postHandler;
        this.postLikeRepository = postLikeRepository;
    }

    /**
     * Likes a post on behalf of a user.
     *
     * @param postId The ID of the post to be liked.
     * @param userId The ID of the user liking the post.
     */
    @Override
    public void likePost(Long postId, Long userId) {

        Post post = postHandler.findById(postId);
        User user = userHandler.findById(userId);

        PostLike postLike = PostLike.builder()
                .post(post)
                .user(user)
                .build();

        postLikeRepository.save(postLike);

        setPostLikeCount(post, post.getLikeCount() + 1);
    }

    private void setPostLikeCount(Post post, Integer likeCount) {
        post.setLikeCount(likeCount);
        postHandler.save(post);
    }

    /**
     * Removes a like from a post.
     *
     * @param postId The ID of the post from which the like should be removed.
     * @param userId The ID of the user who has previously liked the post.
     */
    @Override
    public void unlikePost(Long postId, Long userId) {

        Optional<PostLike> postLike = postLikeRepository.findByPostAndUser(postId, userId);
        if (postLike.isPresent()) {
            postLikeRepository.delete(postLike.get());

            Post post = postHandler.findById(postId);
            if (post.getLikeCount() != null && post.getLikeCount() > 0) {
                setPostLikeCount(post, post.getLikeCount() - 1);
            }
        }

    }
}
