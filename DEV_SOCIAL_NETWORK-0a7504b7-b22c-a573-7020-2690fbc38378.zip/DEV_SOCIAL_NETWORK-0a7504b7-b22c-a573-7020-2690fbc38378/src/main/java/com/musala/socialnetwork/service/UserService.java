package com.musala.socialnetwork.service;

import com.musala.socialnetwork.dto.request.UserRequestDto;
import com.musala.socialnetwork.dto.response.UserResponseDto;

public interface UserService {

    /**
     * Creates a new user based on the provided UserRequestDto.
     *
     * @param userRequestDto The UserRequestDto object containing the data for the new user.
     * @return UserResponseDto representing the created user.
     */
    UserResponseDto createUser(UserRequestDto userRequestDto);
}
