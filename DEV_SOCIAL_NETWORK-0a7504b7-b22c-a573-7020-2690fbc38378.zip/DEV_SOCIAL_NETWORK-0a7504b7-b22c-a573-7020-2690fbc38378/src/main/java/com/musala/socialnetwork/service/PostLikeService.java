package com.musala.socialnetwork.service;

public interface PostLikeService {

    /**
     * Likes a post on behalf of a user.
     *
     * @param postId The ID of the post to be liked.
     * @param userId The ID of the user liking the post.
     */
    void likePost(Long postId, Long userId);

    /**
     * Removes a like from a post.
     *
     * @param postId The ID of the post from which the like should be removed.
     * @param userId The ID of the user who has previously liked the post.
     */
    void unlikePost(Long postId, Long userId);
}
